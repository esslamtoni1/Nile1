import 'package:flutter/material.dart';
import 'package:nile_store/l10n/app_localizations.dart';

/// أقسام مبدئية للعرض فقط. ستأتي من Firestore في المرحلة 3.
class CategoryItem {
  const CategoryItem(this.key, this.icon);
  final String key;
  final IconData icon;
}

const List<CategoryItem> kCategories = [
  CategoryItem('electronics', Icons.devices_rounded),
  CategoryItem('fashion', Icons.checkroom_rounded),
  CategoryItem('homeKitchen', Icons.kitchen_rounded),
  CategoryItem('beauty', Icons.spa_rounded),
  CategoryItem('groceries', Icons.local_grocery_store_rounded),
  CategoryItem('sports', Icons.sports_soccer_rounded),
  CategoryItem('books', Icons.menu_book_rounded),
  CategoryItem('toys', Icons.toys_rounded),
];

String categoryLabel(AppLocalizations l, String key) {
  switch (key) {
    case 'electronics':
      return l.catElectronics;
    case 'fashion':
      return l.catFashion;
    case 'homeKitchen':
      return l.catHomeKitchen;
    case 'beauty':
      return l.catBeauty;
    case 'groceries':
      return l.catGroceries;
    case 'sports':
      return l.catSports;
    case 'books':
      return l.catBooks;
    case 'toys':
      return l.catToys;
    default:
      return key;
  }
}
