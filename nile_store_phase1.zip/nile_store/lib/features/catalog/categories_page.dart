import 'package:flutter/material.dart';
import 'package:nile_store/core/theme.dart';
import 'package:nile_store/data/categories.dart';
import 'package:nile_store/l10n/app_localizations.dart';

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(l.navCategories)),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: kCategories.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final c = kCategories[i];
          return ListTile(
            tileColor: NileColors.mist,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
            leading: Icon(c.icon, color: NileColors.nile),
            title: Text(categoryLabel(l, c.key)),
            trailing: const Icon(Icons.chevron_right_rounded),
          );
        },
      ),
    );
  }
}
