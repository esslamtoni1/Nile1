import 'package:flutter/material.dart';
import 'package:nile_store/core/theme.dart';
import 'package:nile_store/l10n/app_localizations.dart';
import 'package:nile_store/widgets/language_chips.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  void _soon(BuildContext context) {
    final l = AppLocalizations.of(context)!;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(l.comingSoon)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(l.accountTitle)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: NileColors.mist,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              children: [
                const CircleAvatar(
                  radius: 28,
                  backgroundColor: NileColors.nile,
                  child: Icon(Icons.person_rounded, color: Colors.white),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        l.guestUser,
                        style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.w700,
                            ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        l.guestHint,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: () => _soon(context),
            icon: const Icon(Icons.login_rounded),
            label: Text(l.signInWithGoogle),
          ),
          const SizedBox(height: 24),
          Text(
            l.language,
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  fontWeight: FontWeight.w700,
                  color: NileColors.deep,
                ),
          ),
          const SizedBox(height: 10),
          const Align(
            alignment: AlignmentDirectional.centerStart,
            child: LanguageChips(),
          ),
          const SizedBox(height: 16),
          ListTile(
            leading: const Icon(Icons.receipt_long_rounded),
            title: Text(l.myOrders),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => _soon(context),
          ),
          ListTile(
            leading: const Icon(Icons.info_outline_rounded),
            title: Text(l.version),
            trailing: const Text('0.1.0'),
          ),
        ],
      ),
    );
  }
}
