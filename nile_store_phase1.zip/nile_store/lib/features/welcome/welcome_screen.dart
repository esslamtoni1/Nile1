import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:nile_store/core/locale_controller.dart';
import 'package:nile_store/core/theme.dart';
import 'package:nile_store/l10n/app_localizations.dart';
import 'package:nile_store/widgets/language_chips.dart';
import 'package:nile_store/widgets/nile_logo.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final l = AppLocalizations.of(context)!;

    return Scaffold(
      body: Container(
        width: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [NileColors.deep, NileColors.nile, NileColors.sky],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const Spacer(flex: 2),
                const NileLogo(size: 96, onDark: true),
                const SizedBox(height: 20),
                Text(
                  l.appName,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w800,
                      ),
                ),
                const SizedBox(height: 8),
                Text(
                  l.tagline,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.white.withValues(alpha: 0.9),
                      ),
                ),
                const Spacer(),
                Text(
                  l.chooseLanguage,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color: Colors.white.withValues(alpha: 0.9),
                      ),
                ),
                const SizedBox(height: 12),
                const LanguageChips(onDark: true),
                const Spacer(),
                FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: NileColors.nile,
                  ),
                  onPressed: () =>
                      context.read<LocaleController>().completeOnboarding(),
                  child: Text(l.continueAsGuest),
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.white,
                    side: const BorderSide(color: Colors.white70),
                  ),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(l.comingSoon)),
                    );
                  },
                  icon: const Icon(Icons.login_rounded),
                  label: Text(l.signInWithGoogle),
                ),
                const SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
