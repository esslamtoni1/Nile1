import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// يحفظ لغة التطبيق وهل أنهى المستخدم شاشة الترحيب.
class LocaleController extends ChangeNotifier {
  static const _localeKey = 'app_locale';
  static const _onboardedKey = 'onboarded';

  Locale? _locale;
  bool _onboarded = false;

  Locale? get locale => _locale;
  bool get onboarded => _onboarded;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_localeKey);
    if (code != null) {
      _locale = Locale(code);
    }
    _onboarded = prefs.getBool(_onboardedKey) ?? false;
    notifyListeners();
  }

  Future<void> setLocale(Locale locale) async {
    _locale = locale;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_localeKey, locale.languageCode);
  }

  Future<void> completeOnboarding() async {
    _onboarded = true;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_onboardedKey, true);
  }
}
