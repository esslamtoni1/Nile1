import 'package:flutter/material.dart';

/// ألوان نايل ستور: أزرق النيل والأبيض والسماوي.
class NileColors {
  static const Color nile = Color(0xFF0B5FA5);
  static const Color deep = Color(0xFF083B66);
  static const Color sky = Color(0xFF4FC3F7);
  static const Color mist = Color(0xFFEAF6FD);
}

ThemeData buildNileTheme() {
  final scheme = ColorScheme.fromSeed(
    seedColor: NileColors.nile,
    primary: NileColors.nile,
    secondary: NileColors.sky,
    surface: Colors.white,
  );

  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: Colors.white,
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: Colors.white,
      indicatorColor: NileColors.mist,
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
  );
}
