import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:nile_store/core/locale_controller.dart';
import 'package:nile_store/core/theme.dart';
import 'package:nile_store/features/home/home_shell.dart';
import 'package:nile_store/features/welcome/welcome_screen.dart';
import 'package:nile_store/l10n/app_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final controller = LocaleController();
  await controller.load();
  runApp(
    ChangeNotifierProvider<LocaleController>.value(
      value: controller,
      child: const NileStoreApp(),
    ),
  );
}

class NileStoreApp extends StatelessWidget {
  const NileStoreApp({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<LocaleController>();

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      onGenerateTitle: (context) => AppLocalizations.of(context)!.appName,
      theme: buildNileTheme(),
      locale: controller.locale,
      supportedLocales: AppLocalizations.supportedLocales,
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: controller.onboarded ? const HomeShell() : const WelcomeScreen(),
    );
  }
}
