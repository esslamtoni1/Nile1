import 'package:flutter/material.dart';
import 'package:nile_store/core/theme.dart';

/// شعار مبدئي: دائرة بتدرج أزرق وأيقونة متجر. يُستبدل بشعارك لاحقاً.
class NileLogo extends StatelessWidget {
  const NileLogo({super.key, this.size = 48, this.onDark = false});

  final double size;
  final bool onDark;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: onDark
            ? null
            : const LinearGradient(
                colors: [NileColors.nile, NileColors.sky],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
        color: onDark ? Colors.white : null,
      ),
      child: Icon(
        Icons.storefront_rounded,
        size: size * 0.55,
        color: onDark ? NileColors.nile : Colors.white,
      ),
    );
  }
}
