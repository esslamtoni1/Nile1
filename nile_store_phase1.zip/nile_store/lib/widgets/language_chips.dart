import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:nile_store/core/locale_controller.dart';
import 'package:nile_store/core/theme.dart';

/// اختيار اللغة: العربية / English / Français (بأسمائها الأصلية دائماً).
class LanguageChips extends StatelessWidget {
  const LanguageChips({super.key, this.onDark = false});

  final bool onDark;

  static const List<(String, String)> _languages = [
    ('ar', 'العربية'),
    ('en', 'English'),
    ('fr', 'Français'),
  ];

  @override
  Widget build(BuildContext context) {
    final controller = context.watch<LocaleController>();
    final current = controller.locale?.languageCode ??
        Localizations.localeOf(context).languageCode;

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      alignment: WrapAlignment.center,
      children: [
        for (final (code, name) in _languages)
          ChoiceChip(
            label: Text(name),
            selected: current == code,
            showCheckmark: false,
            onSelected: (_) => controller.setLocale(Locale(code)),
            selectedColor: onDark ? Colors.white : NileColors.nile,
            backgroundColor:
                onDark ? Colors.white.withValues(alpha: 0.18) : NileColors.mist,
            side: BorderSide.none,
            labelStyle: TextStyle(
              fontWeight: FontWeight.w600,
              color: current == code
                  ? (onDark ? NileColors.nile : Colors.white)
                  : (onDark ? Colors.white : NileColors.deep),
            ),
          ),
      ],
    );
  }
}
