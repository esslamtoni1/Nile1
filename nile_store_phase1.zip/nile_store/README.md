# Nile Store (نايل ستور) — المرحلة 1

متجر إلكتروني لأندرويد، بثلاث لغات (العربية / English / Français)، بألوان أزرق النيل والأبيض والسماوي.

## ما في هذه المرحلة
- ثيم بألوان النيل، ودعم RTL تلقائي للعربية
- شاشة ترحيب: اختيار اللغة، متابعة كزائر (زر جوجل يظهر "قريباً")
- الرئيسية، الأقسام، السلة (فارغة)، الحساب مع تبديل اللغة
- لا يحتاج Firebase بعد، لذلك يُبنى الـ APK بدون أي مفاتيح

## بناء ملف APK مجاناً بدون تثبيت أي شيء (عبر GitHub)
1. أنشئ حساباً مجانياً على github.com.
2. أنشئ مستودعاً جديداً (New repository) باسم `nile-store`، ويفضّل Private.
3. ارفع كل محتويات هذا المجلد إلى المستودع (Add file ← Upload files). تأكد أن المجلد المخفي `.github` رُفع أيضاً.
4. افتح تبويب **Actions** ← **Build APK** ← **Run workflow**.
5. بعد 5 إلى 10 دقائق افتح التشغيل المكتمل، ونزّل **nile-store-apk** من قسم Artifacts، وفكّ الضغط لتجد `app-release.apk`.
6. انقل الملف لهاتفك وثبّته (يلزم السماح بالتثبيت من مصادر غير معروفة).

## البناء على جهازك (اختياري)
```bash
flutter create --platforms=android --org com.nilestore --project-name nile_store .
flutter pub get
flutter build apk --release
```
الملف الناتج: `build/app/outputs/flutter-apk/app-release.apk`

## المرحلة التالية
تسجيل الدخول بجوجل وكزائر عبر Firebase (سنحتاج وقتها ملف google-services.json).
